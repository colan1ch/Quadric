﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace ProjectEmae
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int RightAnswer = 0;
        int CorrectAnswers = 0;
        int WrongAnswers = 0;
        int TasksCount = 3;
        int GeneralTasksCount = 4;
        int CurrentTask = 0;
        List<int> TasksNumbers = new List<int>();
        private void GoTest_Click(object sender, RoutedEventArgs e)
        {
            CorrectAnswers = 0;
            WrongAnswers = 0;
            CurrentTask = 0;
            TasksCount = Convert.ToInt32(SetTasksCount.Text);
            SetTasksCount.Visibility = Visibility.Hidden;
            TasksNumbers.Clear();
            for (int i = 0; i < GeneralTasksCount; i++)
            {
                TasksNumbers.Add(i + 1);
            }
            Random rand = new Random();
            int number = rand.Next(1, TasksNumbers.Count() + 1);
            number = TasksNumbers[number - 1];
            TasksNumbers.Remove(number);
            string taskPath = @"c:\test\task" + number.ToString() + ".jpg";
            string answerPath = @"c:\test\ans" + number.ToString() + ".txt";
            StreamReader fr = new StreamReader(answerPath);
            string variant1 = fr.ReadLine();
            string variant2 = fr.ReadLine();
            string variant3 = fr.ReadLine();
            string variant4 = fr.ReadLine();
            AnswerOptions.Text = variant1 + "\n" + variant2 + "\n" + variant3 + "\n" + variant4;
            RightAnswer = Convert.ToInt32(fr.ReadLine());
            Uri uri = new Uri(taskPath, UriKind.Absolute);
            img.Source = new BitmapImage(uri);
            GoTest.Visibility = Visibility.Hidden;
            Result.Visibility = Visibility.Hidden;
            A.Visibility = Visibility.Visible;
            B.Visibility = Visibility.Visible;
            C.Visibility = Visibility.Visible;
            D.Visibility = Visibility.Visible;
            img.Visibility = Visibility.Visible;
            AnswerOptions.Visibility = Visibility.Visible;
        }

        
        private void A_Click(object sender, RoutedEventArgs e)
        {
            if (RightAnswer == 1)
            {
                CorrectAnswers++;
            }
            else
            {
                WrongAnswers++;
            }
            CurrentTask++;
            if (CurrentTask == TasksCount)
            {
                img.Visibility = Visibility.Hidden;
                A.Visibility = Visibility.Hidden;
                B.Visibility = Visibility.Hidden;
                C.Visibility = Visibility.Hidden;
                D.Visibility = Visibility.Hidden;
                AnswerOptions.Visibility = Visibility.Hidden;
                Result.Visibility = Visibility.Visible;
                Result.Text = "Правильные: " + CorrectAnswers.ToString() + "\n" + "Неправильные: " + WrongAnswers.ToString();
                GoTest.Visibility = Visibility.Visible;
            }
            else
            {
                Random rand = new Random();
                int number = rand.Next(1, TasksNumbers.Count() + 1);
                number = TasksNumbers[number - 1];
                TasksNumbers.Remove(number);
                string taskPath = @"c:\test\task" + number.ToString() + ".jpg";
                string answerPath = @"c:\test\ans" + number.ToString() + ".txt";
                StreamReader fr = new StreamReader(answerPath);
                string variant1 = fr.ReadLine();
                string variant2 = fr.ReadLine();
                string variant3 = fr.ReadLine();
                string variant4 = fr.ReadLine();
                AnswerOptions.Text = variant1 + "\n" + variant2 + "\n" + variant3 + "\n" + variant4;
                RightAnswer = Convert.ToInt32(fr.ReadLine());
                Uri uri = new Uri(taskPath, UriKind.Absolute);
                img.Source = new BitmapImage(uri);
            }
        }

        private void B_Click(object sender, RoutedEventArgs e)
        {
            if (RightAnswer == 2)
            {
                CorrectAnswers++;
            }
            else
            {
                WrongAnswers++;
            }
            CurrentTask++;
            if (CurrentTask == TasksCount)
            {
                img.Visibility = Visibility.Hidden;
                A.Visibility = Visibility.Hidden;
                B.Visibility = Visibility.Hidden;
                C.Visibility = Visibility.Hidden;
                D.Visibility = Visibility.Hidden;
                AnswerOptions.Visibility = Visibility.Hidden;
                Result.Visibility = Visibility.Visible;
                Result.Text = "Правильные: " + CorrectAnswers.ToString() + "\n" + "Неправильные: " + WrongAnswers.ToString();
                GoTest.Visibility = Visibility.Visible;
            }
            else
            {
                Random rand = new Random();
                int number = rand.Next(1, TasksNumbers.Count() + 1);
                number = TasksNumbers[number - 1];
                TasksNumbers.Remove(number);
                string taskPath = @"c:\test\task" + number.ToString() + ".jpg";
                string answerPath = @"c:\test\ans" + number.ToString() + ".txt";
                StreamReader fr = new StreamReader(answerPath);
                string variant1 = fr.ReadLine();
                string variant2 = fr.ReadLine();
                string variant3 = fr.ReadLine();
                string variant4 = fr.ReadLine();
                AnswerOptions.Text = variant1 + "\n" + variant2 + "\n" + variant3 + "\n" + variant4;
                RightAnswer = Convert.ToInt32(fr.ReadLine());
                Uri uri = new Uri(taskPath, UriKind.Absolute);
                img.Source = new BitmapImage(uri);
            }
        }

        private void C_Click(object sender, RoutedEventArgs e)
        {
            if (RightAnswer == 3)
            {
                CorrectAnswers++;
            }
            else
            {
                WrongAnswers++;
            }
            CurrentTask++;
            if (CurrentTask == TasksCount)
            {
                img.Visibility = Visibility.Hidden;
                A.Visibility = Visibility.Hidden;
                B.Visibility = Visibility.Hidden;
                C.Visibility = Visibility.Hidden;
                D.Visibility = Visibility.Hidden;
                AnswerOptions.Visibility = Visibility.Hidden;
                Result.Visibility = Visibility.Visible;
                Result.Text = "Правильные: " + CorrectAnswers.ToString() + "\n" + "Неправильные: " + WrongAnswers.ToString();
                GoTest.Visibility = Visibility.Visible;
            }
            else
            {
                Random rand = new Random();
                int number = rand.Next(1, TasksNumbers.Count() + 1);
                number = TasksNumbers[number - 1];
                TasksNumbers.Remove(number);
                string taskPath = @"c:\test\task" + number.ToString() + ".jpg";
                string answerPath = @"c:\test\ans" + number.ToString() + ".txt";
                StreamReader fr = new StreamReader(answerPath);
                string variant1 = fr.ReadLine();
                string variant2 = fr.ReadLine();
                string variant3 = fr.ReadLine();
                string variant4 = fr.ReadLine();
                AnswerOptions.Text = variant1 + "\n" + variant2 + "\n" + variant3 + "\n" + variant4;
                RightAnswer = Convert.ToInt32(fr.ReadLine());
                Uri uri = new Uri(taskPath, UriKind.Absolute);
                img.Source = new BitmapImage(uri);
            }
        }

        private void D_Click(object sender, RoutedEventArgs e)
        {
            if (RightAnswer == 4)
            {
                CorrectAnswers++;
            }
            else
            {
                WrongAnswers++;
            }
            CurrentTask++;
            if (CurrentTask == TasksCount)
            {
                img.Visibility = Visibility.Hidden;
                A.Visibility = Visibility.Hidden;
                B.Visibility = Visibility.Hidden;
                C.Visibility = Visibility.Hidden;
                D.Visibility = Visibility.Hidden;
                AnswerOptions.Visibility = Visibility.Hidden;
                Result.Visibility = Visibility.Visible;
                Result.Text = "Правильные: " + CorrectAnswers.ToString() + "\n" + "Неправильные: " + WrongAnswers.ToString();
                GoTest.Visibility = Visibility.Visible;
            }
            else
            {
                Random rand = new Random();
                int number = rand.Next(1, TasksNumbers.Count() + 1);
                number = TasksNumbers[number - 1];
                TasksNumbers.Remove(number);
                string taskPath = @"c:\test\task" + number.ToString() + ".jpg";
                string answerPath = @"c:\test\ans" + number.ToString() + ".txt";
                StreamReader fr = new StreamReader(answerPath);
                string variant1 = fr.ReadLine();
                string variant2 = fr.ReadLine();
                string variant3 = fr.ReadLine();
                string variant4 = fr.ReadLine();
                AnswerOptions.Text = variant1 + "\n" + variant2 + "\n" + variant3 + "\n" + variant4;
                RightAnswer = Convert.ToInt32(fr.ReadLine());
                Uri uri = new Uri(taskPath, UriKind.Absolute);
                img.Source = new BitmapImage(uri);
            }
        }
    }
}
